"""
Memory Agent
Persistent semantic memory using ChromaDB + Ollama embeddings.
Supports episodic, semantic, and procedural memory types.
"""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

import chromadb
from chromadb.config import Settings

from config.llm_client import OllamaClient
from config.models import MemoryItem, MemoryType
from config.settings import (
    CHROMA_DIR,
    MEMORY_COLLECTION_NAME,
    MEMORY_SIMILARITY_THRESHOLD,
    MEMORY_TOP_K,
)


class MemoryAgent:
    """
    Persistent vector memory using ChromaDB.

    Replaces the in-memory numpy implementation with a proper
    vector database that survives restarts — addressing the
    'non-persistent memory' limitation from the interim report.

    Memory types:
      - episodic:   things that happened ("Scheduled meeting with Alice on Tuesday")
      - semantic:   facts and preferences ("User prefers afternoon meetings")
      - procedural: how to do things ("To book a meeting: first check conflicts")
    """

    def __init__(self, llm_client: Optional[OllamaClient] = None):
        self.llm = llm_client or OllamaClient()

        # Persistent ChromaDB client
        self.chroma = chromadb.PersistentClient(
            path=str(CHROMA_DIR),
            settings=Settings(anonymized_telemetry=False),
        )

        self.collection = self.chroma.get_or_create_collection(
            name=MEMORY_COLLECTION_NAME,
            metadata={"hnsw:space": "cosine"},
        )

        print(f"🧠 MemoryAgent ready — {self.collection.count()} memories loaded")

    # ── Store ──────────────────────────────────────────────────────────────

    async def store(
        self,
        content: str,
        memory_type: MemoryType = MemoryType.EPISODIC,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> MemoryItem:
        """
        Store a memory with its embedding in ChromaDB.

        Args:
            content:     Text to remember
            memory_type: episodic | semantic | procedural
            metadata:    Extra context (tags, task_id, etc.)

        Returns:
            The stored MemoryItem
        """
        mem_id = f"mem_{uuid.uuid4().hex[:12]}"
        now = datetime.now()

        embedding = await self.llm.embed(content)

        chroma_metadata = {
            "memory_type": memory_type.value,
            "created_at": now.isoformat(),
            **(metadata or {}),
        }
        # ChromaDB metadata values must be str | int | float | bool
        chroma_metadata = {
            k: str(v) if not isinstance(v, (str, int, float, bool)) else v
            for k, v in chroma_metadata.items()
        }

        self.collection.add(
            ids=[mem_id],
            embeddings=[embedding],
            documents=[content],
            metadatas=[chroma_metadata],
        )

        print(f"💾 Memory stored [{memory_type.value}]: {content[:60]}...")

        return MemoryItem(
            id=mem_id,
            content=content,
            memory_type=memory_type,
            metadata=chroma_metadata,
            created_at=now,
        )

    # ── Retrieve ───────────────────────────────────────────────────────────

    async def retrieve(
        self,
        query: str,
        memory_type: Optional[MemoryType] = None,
        k: int = MEMORY_TOP_K,
        threshold: float = MEMORY_SIMILARITY_THRESHOLD,
    ) -> List[MemoryItem]:
        """
        Retrieve semantically relevant memories.

        Args:
            query:       Natural language search query
            memory_type: Optional filter by type
            k:           Max results to return
            threshold:   Min cosine similarity (0–1)

        Returns:
            List of MemoryItems sorted by relevance
        """
        if self.collection.count() == 0:
            return []

        query_embedding = await self.llm.embed(query)

        where_filter = (
            {"memory_type": memory_type.value} if memory_type else None
        )

        results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=min(k, self.collection.count()),
            where=where_filter,
            include=["documents", "metadatas", "distances"],
        )

        memories: List[MemoryItem] = []
        for doc, meta, distance in zip(
            results["documents"][0],
            results["metadatas"][0],
            results["distances"][0],
        ):
            # ChromaDB cosine distance → similarity
            similarity = 1.0 - distance
            if similarity < threshold:
                continue

            memories.append(
                MemoryItem(
                    id=meta.get("id", ""),
                    content=doc,
                    memory_type=MemoryType(meta.get("memory_type", "episodic")),
                    metadata=meta,
                    created_at=datetime.fromisoformat(
                        meta.get("created_at", datetime.now().isoformat())
                    ),
                    relevance_score=round(similarity, 4),
                )
            )

        return memories

    # ── Utility ────────────────────────────────────────────────────────────

    async def store_task_result(
        self,
        user_request: str,
        intent: str,
        success: bool,
        summary: str,
    ) -> None:
        """Convenience: store an episodic memory after task execution."""
        content = (
            f"Task: {user_request} | Intent: {intent} | "
            f"Success: {success} | Summary: {summary}"
        )
        await self.store(
            content,
            memory_type=MemoryType.EPISODIC,
            metadata={"intent": intent, "success": str(success)},
        )

    def get_count(self) -> int:
        return self.collection.count()

    async def clear(self) -> None:
        """Delete all memories — use only in tests."""
        self.chroma.delete_collection(MEMORY_COLLECTION_NAME)
        self.collection = self.chroma.get_or_create_collection(
            name=MEMORY_COLLECTION_NAME,
            metadata={"hnsw:space": "cosine"},
        )
        print("🗑️  Memory cleared")
